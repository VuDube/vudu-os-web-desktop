--
-- Supabase Schema for vudu OS
--
-- This schema is designed to support the core functionality of vudu OS,
-- including user profiles, a virtual file system (VFS) metadata, and
-- real-time updates, while adhering to the Supabase free tier limits.
--

-- Enable the 'uuid-ossp' extension for generating UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

--
-- Table: profiles
-- Stores user profile information and links to Supabase Auth.
--
CREATE TABLE profiles (
  id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL PRIMARY KEY,
  username text UNIQUE,
  full_name text,
  avatar_url text,
  -- Custom settings for the OS (e.g., theme, desktop background)
  os_settings jsonb DEFAULT '{}'::jsonb,
  updated_at timestamp with time zone
);

-- Set up Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own profile and a list of all users (for collaboration/sharing)
CREATE POLICY "Users can view their own profile." ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile." ON profiles FOR UPDATE USING (auth.uid() = id);

-- Function to create a new profile upon user sign-up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'avatar_url');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to call the function when a new user is created in auth.users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

--
-- Table: vfs_metadata (Virtual File System Metadata)
-- Stores metadata for all files and folders in the UFS.
-- The actual file content is stored in Supabase Storage or Cloudinary.
--
CREATE TABLE vfs_metadata (
  id uuid DEFAULT uuid_generate_v4() NOT NULL PRIMARY KEY,
  owner_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  parent_id uuid REFERENCES vfs_metadata(id) ON DELETE CASCADE, -- Null for root folder
  name text NOT NULL,
  type text NOT NULL, -- 'folder', 'file', 'link'
  storage_type text NOT NULL, -- 'supabase', 'cloudinary', 'local'
  storage_path text, -- Path in Supabase Storage or Cloudinary public_id
  mime_type text,
  size_bytes bigint,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL,
  is_public boolean DEFAULT FALSE NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb -- For Cloudinary tags, local path, etc.
);

-- Set up Row Level Security (RLS)
ALTER TABLE vfs_metadata ENABLE ROW LEVEL SECURITY;

-- Policies for VFS:
-- 1. Users can see their own files and public files
CREATE POLICY "Users can view their own files and public files." ON vfs_metadata FOR SELECT USING (auth.uid() = owner_id OR is_public = TRUE);
-- 2. Users can create files
CREATE POLICY "Users can create files." ON vfs_metadata FOR INSERT WITH CHECK (auth.uid() = owner_id);
-- 3. Users can update their own files
CREATE POLICY "Users can update their own files." ON vfs_metadata FOR UPDATE USING (auth.uid() = owner_id);
-- 4. Users can delete their own files
CREATE POLICY "Users can delete their own files." ON vfs_metadata FOR DELETE USING (auth.uid() = owner_id);

-- Index for faster lookups by owner and parent
CREATE INDEX vfs_owner_parent_idx ON vfs_metadata (owner_id, parent_id);

--
-- Real-time setup:
-- Supabase Realtime is automatically enabled for tables with RLS.
-- We will enable it for `vfs_metadata` to get live file system updates.
--
-- In the Supabase Dashboard, go to Database -> Replication and enable
-- the `vfs_metadata` table for real-time changes.
--

--
-- Initial Data (Optional: Create a root folder for each user)
-- This can be handled in the `handle_new_user` function or on first login.
-- For simplicity, we'll assume the client handles the creation of the user's
-- root folder on first login if it doesn't exist.
--

--
-- Storage Buckets:
-- Supabase Storage will require a bucket, e.g., 'vudu-files'.
-- Cloudinary is external, so no bucket needed here.
--
-- In the Supabase Dashboard, go to Storage and create a new bucket named 'vudu-files'.
-- Set up RLS policies for the bucket to allow authenticated users to upload/download.
--

--
-- Example RLS for Supabase Storage bucket 'vudu-files':
--
-- CREATE POLICY "Allow authenticated users to upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'vudu-files');
-- CREATE POLICY "Allow authenticated users to read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'vudu-files');
-- CREATE POLICY "Allow authenticated users to delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'vudu-files');
--
