//
// /frontend/src/store/useOSStore.ts
// Global state management for vudu OS using Zustand
//

import { create } from 'zustand';
import { WindowState, AppManifest, UserProfile } from '@shared/types';
import { v4 as uuidv4 } from 'uuid';

// Define the state structure
interface OSState {
  // Core OS State
  isLoggedIn: boolean;
  profile: UserProfile | null;
  windows: WindowState[];
  apps: AppManifest[];
  activeWindowId: string | null;
  nextZIndex: number;

  // Actions
  setLoggedIn: (isLoggedIn: boolean, profile: UserProfile | null) => void;
  registerApp: (app: AppManifest) => void;
  openApp: (appId: string, initialProps?: Partial<WindowState>) => void;
  closeWindow: (windowId: string) => void;
  focusWindow: (windowId: string) => void;
  updateWindow: (windowId: string, updates: Partial<WindowState>) => void;
}

// Initial state
const initialState: Omit<OSState, 'setLoggedIn' | 'registerApp' | 'openApp' | 'closeWindow' | 'focusWindow' | 'updateWindow'> = {
  isLoggedIn: false,
  profile: null,
  windows: [],
  apps: [],
  activeWindowId: null,
  nextZIndex: 1000,
};

// Create the store
export const useOSStore = create<OSState>((set, get) => ({
  ...initialState,

  setLoggedIn: (isLoggedIn, profile) => set({ isLoggedIn, profile }),

  registerApp: (app) => set((state) => {
    if (state.apps.some(a => a.id === app.id)) {
      return state; // App already registered
    }
    return { apps: [...state.apps, app] };
  }),

  openApp: (appId, initialProps = {}) => set((state) => {
    const app = state.apps.find(a => a.id === appId);
    if (!app) {
      console.error(`App with ID ${appId} not found.`);
      return state;
    }

    const newZIndex = state.nextZIndex + 1;
    const newWindow: WindowState = {
      id: uuidv4(),
      appId: appId,
      title: app.name,
      icon: app.icon,
      x: 50 + (state.windows.length * 20) % 100,
      y: 50 + (state.windows.length * 20) % 100,
      width: 800,
      height: 600,
      isMinimized: false,
      isMaximized: false,
      zIndex: newZIndex,
      ...initialProps,
    };

    return {
      windows: [...state.windows, newWindow],
      activeWindowId: newWindow.id,
      nextZIndex: newZIndex,
    };
  }),

  closeWindow: (windowId) => set((state) => ({
    windows: state.windows.filter(w => w.id !== windowId),
    activeWindowId: state.activeWindowId === windowId ? null : state.activeWindowId,
  })),

  focusWindow: (windowId) => set((state) => {
    if (state.activeWindowId === windowId) return state;

    const windowToFocus = state.windows.find(w => w.id === windowId);
    if (!windowToFocus) return state;

    const newZIndex = state.nextZIndex + 1;
    const updatedWindows = state.windows.map(w =>
      w.id === windowId ? { ...w, zIndex: newZIndex, isMinimized: false } : w
    );

    return {
      windows: updatedWindows,
      activeWindowId: windowId,
      nextZIndex: newZIndex,
    };
  }),

  updateWindow: (windowId, updates) => set((state) => ({
    windows: state.windows.map(w =>
      w.id === windowId ? { ...w, ...updates } : w
    ),
  })),
}));
