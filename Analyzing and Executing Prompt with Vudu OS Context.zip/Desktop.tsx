//
// /frontend/src/components/Desktop/Desktop.tsx
// The main desktop background component
//

import React from 'react';

export const Desktop: React.FC = () => {
  return (
    <div className="desktop" onClick={() => { /* Deselect all desktop items */ }}>
      {/* Desktop icons and widgets will go here */}
    </div>
  );
};
