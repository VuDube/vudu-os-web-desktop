//
// /frontend/src/apps/FileExplorer/FileExplorerApp.tsx
// File Explorer Application (Placeholder)
//

import React from 'react';
import { AppProps } from '@shared/types';

export const FileExplorerApp: React.FC<AppProps> = ({ windowId, onClose }) => {
  return (
    <div>
      <h2>📁 File Explorer</h2>
      <p>Universal File System (UFS) interface to navigate local, Supabase, and Cloudinary storage.</p>
      <p>Window ID: {windowId}</p>
      <button onClick={onClose}>Close App</button>
    </div>
  );
};
