//
// /frontend/src/apps/apps.ts
// Central registry for all vudu OS applications
//

import { useOSStore } from '../store/useOSStore';
import { AppManifest } from '@shared/types';

// Import built-in apps
import { FileExplorerApp } from './FileExplorer/FileExplorerApp';
import { TextEditorApp } from './TextEditor/TextEditorApp';
import { CloudflareManagerApp } from './CloudflareManager/CloudflareManagerApp';
import { MediaViewerApp } from './MediaViewer/MediaViewerApp';
import { SystemSettingsApp } from './SystemSettings/SystemSettingsApp';

// Define the manifest for each built-in application
const builtInApps: AppManifest[] = [
  {
    id: 'file-explorer',
    name: 'File Explorer',
    icon: '📁',
    component: FileExplorerApp,
    isExternal: false,
  },
  {
    id: 'text-editor',
    name: 'Text Editor',
    icon: '📝',
    component: TextEditorApp,
    isExternal: false,
  },
  {
    id: 'cloudflare-manager',
    name: 'Cloudflare Manager',
    icon: '☁️',
    component: CloudflareManagerApp,
    isExternal: false,
  },
  {
    id: 'media-viewer',
    name: 'Media Viewer',
    icon: '🖼️',
    component: MediaViewerApp,
    isExternal: false,
  },
  {
    id: 'system-settings',
    name: 'System Settings',
    icon: '⚙️',
    component: SystemSettingsApp,
    isExternal: false,
  },
  // Example of an external app
  {
    id: 'external-web-app',
    name: 'External Web App',
    icon: '🌐',
    component: () => <div>External App Content (iframe placeholder)</div>,
    isExternal: true,
    url: 'https://example.com',
  }
];

/**
 * Registers all built-in applications with the OS store.
 */
export function registerBuiltInApps() {
  const { registerApp } = useOSStore.getState();
  builtInApps.forEach(registerApp);
}
