# vudu OS Deployment Guide

This guide provides step-by-step instructions for deploying your self-hosted vudu OS instance to **Cloudflare Pages**, leveraging **Supabase** and **Cloudinary** free tiers.

## Prerequisites

Before starting, ensure you have the following accounts set up:

1.  **GitHub Account:** To host the codebase and connect to Cloudflare Pages.
2.  **Cloudflare Account:** For hosting the PWA and serverless functions.
3.  **Supabase Account:** For the database, authentication, and file storage.
4.  **Cloudinary Account:** For media optimization and management.

## Step 1: Prepare the Codebase

1.  **Fork or Clone the Repository:**
    If you received the code as a zip, create a new GitHub repository and push the code to it. If you are starting from a public repository, fork it.

2.  **Add PWA Icons:**
    The PWA requires specific icons. Place your custom icons in the `frontend/public/` directory, named as follows:
    *   `pwa-192x192.png`
    *   `pwa-512x512.png`
    *   `apple-touch-icon.png` (optional, but recommended)
    *   `maskable_icon.png` (optional, but recommended)

## Step 2: Configure Supabase

1.  **Create a New Project:**
    Log in to your Supabase dashboard and create a new project. Note down the **Project URL** and **Anon Public Key** from the **Settings -> API** page.

2.  **Run the SQL Schema:**
    *   Navigate to the **SQL Editor** in your Supabase project.
    *   Copy the contents of the `supabase_schema.sql` file and run the queries to create the `profiles` and `vfs_metadata` tables, and set up Row Level Security (RLS).

3.  **Create Storage Bucket:**
    *   Go to **Storage** and click **New bucket**.
    *   Name the bucket `vudu-files`.
    *   Set up RLS policies for the `vudu-files` bucket to allow authenticated users to upload and download files.

4.  **Obtain Service Role Key:**
    *   Go to **Settings -> API**.
    *   Copy the **Service Role Key** (it is a secret and should only be used in the backend).

## Step 3: Configure Cloudinary

1.  **Create a Cloudinary Account:**
    Sign up for a free Cloudinary account.

2.  **Obtain Credentials:**
    From your Cloudinary dashboard, note down the following:
    *   **Cloud Name**
    *   **API Key**
    *   **API Secret**

## Step 4: Configure Cloudflare API Token

This token is required for the **Cloudflare Manager** app to function (e.g., purging cache).

1.  **Create an API Token:**
    *   Log in to your Cloudflare dashboard.
    *   Go to **My Profile -> API Tokens**.
    *   Click **Create Token**.
    *   Use the **Custom token** option.
    *   **Permissions:** Add the following permissions:
        *   `Zone` -> `Read`
        *   `DNS` -> `Edit`
        *   `Cache Purge` -> `Edit`
    *   **Zone Resources:** Select **All zones** or the specific zone you plan to use.
    *   Note down the generated **API Token**.

2.  **Obtain Account ID:**
    *   Go to your Cloudflare dashboard home.
    *   Find your **Account ID** on the right sidebar.

## Step 5: Deploy to Cloudflare Pages

1.  **Connect GitHub Repository:**
    *   Log in to your Cloudflare dashboard and go to **Pages**.
    *   Click **Create a project** -> **Connect to Git**.
    *   Select the GitHub repository containing the vudu OS code.

2.  **Configure Build Settings:**
    *   **Project Name:** `vudu-os` (or your preferred name)
    *   **Production Branch:** `main` (or your main branch)
    *   **Build command:** `npm run build`
    *   **Build output directory:** `dist`

3.  **Set Environment Variables (Crucial Step):**
    *   Go to the **Environment variables** section.
    *   Add the following variables. **Note:** Variables prefixed with `VITE_` are for the frontend, and the others are for the backend (Pages Functions).

    | Variable Name | Value Source | Type | Notes |
    | :--- | :--- | :--- | :--- |
    | `VITE_SUPABASE_URL` | Supabase Project URL | Production & Preview | Frontend |
    | `VITE_SUPABASE_ANON_KEY` | Supabase Anon Public Key | Production & Preview | Frontend |
    | `SUPABASE_SERVICE_ROLE_KEY` | Supabase Service Role Key | **Secret** | Backend Only |
    | `VITE_CLOUDINARY_CLOUD_NAME` | Cloudinary Cloud Name | Production & Preview | Frontend |
    | `CLOUDINARY_API_KEY` | Cloudinary API Key | **Secret** | Backend Only |
    | `CLOUDINARY_API_SECRET` | Cloudinary API Secret | **Secret** | Backend Only |
    | `CLOUDFLARE_API_TOKEN` | Your Scoped Cloudflare API Token | **Secret** | Backend Only |
    | `CLOUDFLARE_ACCOUNT_ID` | Your Cloudflare Account ID | **Secret** | Backend Only |
    | `N8N_WEBHOOK_BASE_URL` | Your n8n Webhook URL (Optional) | **Secret** | Backend Only |
    | `N8N_WEBHOOK_SECRET` | Your n8n Webhook Secret (Optional) | **Secret** | Backend Only |

4.  **Save and Deploy:**
    *   Click **Save and Deploy**. Cloudflare Pages will now fetch your repository, install dependencies, build the project, and deploy it.

5.  **Access vudu OS:**
    Once the deployment is complete, you can access your fully functional vudu OS PWA at the provided Cloudflare Pages URL.
