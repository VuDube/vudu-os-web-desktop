//
// /frontend/src/components/Auth/LoginScreen.tsx
// User authentication screen using Supabase Auth
//

import React, { useState } from 'react';
import { supabase } from '../../mcp/supabaseClient';

export const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      if (isSigningUp) {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setMessage('Sign up successful! Check your email for the confirmation link.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setMessage('Login successful!');
      }
    } catch (error: any) {
      setMessage(error.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <form className="login-form" onSubmit={handleAuth}>
        <h2>{isSigningUp ? 'Sign Up for vudu OS' : 'Login to vudu OS'}</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Processing...' : (isSigningUp ? 'Sign Up' : 'Login')}
        </button>
        <p style={{ color: 'red', textAlign: 'center' }}>{message}</p>
        <button
          type="button"
          onClick={() => setIsSigningUp(!isSigningUp)}
          style={{ background: 'none', color: '#007bff', border: 'none' }}
        >
          {isSigningUp ? 'Already have an account? Login' : "Don't have an account? Sign Up"}
        </button>
      </form>
    </div>
  );
};
