//
// /mcp/src/cloudinary.ts
// Cloudinary client and utility functions for the backend (Cloudflare Pages Functions)
//

import { v2 as cloudinary, ConfigOptions } from 'cloudinary';
import { Env } from '@shared/types';

let cloudinaryClient: typeof cloudinary | null = null;

/**
 * Initializes and returns a configured Cloudinary client.
 * @param env The environment variables from the Cloudflare Pages Function context.
 * @returns The configured Cloudinary client.
 */
export function getCloudinaryClient(env: Env): typeof cloudinary {
  if (cloudinaryClient) {
    return cloudinaryClient;
  }

  const config: ConfigOptions = {
    cloud_name: env.VITE_CLOUDINARY_CLOUD_NAME, // VITE_ variables are available in CF Pages Functions
    api_key: env.CLOUDINARY_API_KEY,
    api_secret: env.CLOUDINARY_API_SECRET,
    secure: true,
  };

  cloudinary.config(config);
  cloudinaryClient = cloudinary;
  return cloudinaryClient;
}

/**
 * Generates a secure URL for a Cloudinary asset.
 * @param publicId The public ID of the asset.
 * @param options Transformation options.
 * @returns The secure URL string.
 */
export function getCloudinaryUrl(publicId: string, options?: any): string {
  const client = getCloudinaryClient(process.env as unknown as Env); // Assuming env is available globally in CF Worker context
  return client.url(publicId, options);
}

/**
 * Triggers AI analysis and auto-tagging on a Cloudinary asset.
 * @param env The environment variables.
 * @param publicId The public ID of the asset.
 * @returns The result of the update operation.
 */
export async function autoTagCloudinaryAsset(env: Env, publicId: string): Promise<any> {
  const client = getCloudinaryClient(env);
  try {
    const result = await client.uploader.explicit(publicId, {
      type: 'upload',
      eager: [
        { width: 400, height: 300, crop: 'fill' } // Example transformation
      ],
      // Enable Google AI Video/Image Analysis for auto-tagging
      categorization: 'google_tagging',
      auto_tagging: 0.6, // Confidence level
    });
    return result;
  } catch (error) {
    console.error('Error during Cloudinary auto-tagging:', error);
    throw new Error('Failed to auto-tag asset.');
  }
}
