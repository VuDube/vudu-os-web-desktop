//
// /mcp/src/supabase.ts
// Supabase client and utility functions for the backend (Cloudflare Pages Functions)
//

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { VFSNode, Env } from '@shared/types';

let supabaseClient: SupabaseClient | null = null;

/**
 * Initializes and returns a Supabase client with the Service Role Key.
 * This client should ONLY be used in the secure backend (Cloudflare Pages Functions).
 * @param env The environment variables from the Cloudflare Pages Function context.
 * @returns A SupabaseClient instance.
 */
export function getSupabaseServiceRoleClient(env: Env): SupabaseClient {
  if (supabaseClient) {
    return supabaseClient;
  }

  const supabaseUrl = env.VITE_SUPABASE_URL; // VITE_ variables are available in CF Pages Functions
  const supabaseServiceRoleKey = env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !supabaseServiceRoleKey) {
    throw new Error('Supabase URL or Service Role Key is missing in environment variables.');
  }

  supabaseClient = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  return supabaseClient;
}

/**
 * Fetches a VFS node by its ID.
 * @param env The environment variables.
 * @param id The ID of the VFS node.
 * @returns The VFSNode or null if not found.
 */
export async function getVFSNodeById(env: Env, id: string): Promise<VFSNode | null> {
  const supabase = getSupabaseServiceRoleClient(env);
  const { data, error } = await supabase
    .from('vfs_metadata')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Error fetching VFS node:', error);
    return null;
  }

  return data as VFSNode;
}

/**
 * Updates a VFS node's metadata.
 * @param env The environment variables.
 * @param id The ID of the VFS node.
 * @param updates The partial updates to apply.
 * @returns The updated VFSNode or null on error.
 */
export async function updateVFSNode(env: Env, id: string, updates: Partial<VFSNode>): Promise<VFSNode | null> {
  const supabase = getSupabaseServiceRoleClient(env);
  const { data, error } = await supabase
    .from('vfs_metadata')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating VFS node:', error);
    return null;
  }

  return data as VFSNode;
}
