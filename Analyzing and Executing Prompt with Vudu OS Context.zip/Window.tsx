//
// /frontend/src/components/WindowManager/Window.tsx
// A single resizable and draggable application window
//

import React, { useMemo } from 'react';
import { Rnd } from 'react-rnd';
import { useOSStore } from '../../store/useOSStore';
import { WindowState } from '@shared/types';

interface WindowProps {
  windowState: WindowState;
}

export const Window: React.FC<WindowProps> = ({ windowState }) => {
  const { id, title, icon, x, y, width, height, isMinimized, isMaximized, zIndex, appId } = windowState;
  const { apps, focusWindow, closeWindow, updateWindow } = useOSStore();

  const app = useMemo(() => apps.find(a => a.id === appId), [apps, appId]);

  if (!app || isMinimized) {
    return null;
  }

  const handleFocus = () => {
    focusWindow(id);
  };

  const handleClose = () => {
    closeWindow(id);
  };

  const handleMinimize = () => {
    updateWindow(id, { isMinimized: true });
  };

  const handleMaximize = () => {
    if (isMaximized) {
      // Restore logic (simplified for now)
      updateWindow(id, { isMaximized: false, x: 50, y: 50, width: 800, height: 600 });
    } else {
      // Maximize to full desktop area (minus taskbar)
      updateWindow(id, { isMaximized: true, x: 0, y: 0, width: window.innerWidth, height: window.innerHeight - 40 });
    }
  };

  const handleDragStop = (_e: any, d: { x: number, y: number }) => {
    updateWindow(id, { x: d.x, y: d.y });
  };

  const handleResizeStop = (_e: any, _direction: any, ref: HTMLElement, _delta: any, position: { x: number, y: number }) => {
    updateWindow(id, {
      width: parseInt(ref.style.width),
      height: parseInt(ref.style.height),
      x: position.x,
      y: position.y,
    });
  };

  const AppContent = app.component;

  return (
    <Rnd
      size={{ width, height }}
      position={{ x, y }}
      minWidth={300}
      minHeight={200}
      bounds="parent"
      dragHandleClassName="window-header"
      onDragStart={handleFocus}
      onDragStop={handleDragStop}
      onResizeStart={handleFocus}
      onResizeStop={handleResizeStop}
      enableResizing={!isMaximized}
      disableDragging={isMaximized}
      style={{ zIndex }}
      className={`window ${isMaximized ? 'maximized' : ''}`}
    >
      <div className="window-header" onMouseDown={handleFocus} onTouchStart={handleFocus}>
        <div className="window-title">
          <span className="window-icon">{icon}</span>
          {title}
        </div>
        <div className="window-controls">
          <button onClick={handleMinimize} title="Minimize">_</button>
          <button onClick={handleMaximize} title="Maximize">□</button>
          <button onClick={handleClose} title="Close">X</button>
        </div>
      </div>
      <div className="window-content">
        <AppContent windowId={id} onClose={handleClose} />
      </div>
    </Rnd>
  );
};
