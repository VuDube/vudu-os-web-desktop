//
// /frontend/src/apps/TextEditor/TextEditorApp.tsx
// Text Editor Application (Placeholder)
//

import React from 'react';
import { AppProps } from '@shared/types';

export const TextEditorApp: React.FC<AppProps> = ({ windowId, onClose }) => {
  return (
    <div>
      <h2>📝 Text Editor</h2>
      <p>Basic text and code editing functionality.</p>
      <p>Window ID: {windowId}</p>
      <button onClick={onClose}>Close App</button>
    </div>
  );
};
