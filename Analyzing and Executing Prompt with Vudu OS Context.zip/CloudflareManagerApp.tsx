//
// /frontend/src/apps/CloudflareManager/CloudflareManagerApp.tsx
// Cloudflare Manager Application (Placeholder)
//

import React, { useState } from 'react';
import { AppProps } from '@shared/types';

export const CloudflareManagerApp: React.FC<AppProps> = ({ windowId, onClose }) => {
  const [status, setStatus] = useState('');

  const handlePurgeCache = async () => {
    setStatus('Purging cache...');
    try {
      // Hardcoded zoneId for demonstration. In a real app, this would be dynamic.
      const zoneId = 'YOUR_CLOUDFLARE_ZONE_ID';
      const response = await fetch('/api/cloudflare/purge-cache', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ zoneId, purge_everything: true }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setStatus('Cache purged successfully!');
      } else {
        setStatus(`Purge failed: ${data.error || 'Unknown error'}`);
      }
    } catch (error) {
      setStatus(`Purge failed: ${error instanceof Error ? error.message : 'Network error'}`);
    }
  };

  return (
    <div>
      <h2>☁️ Cloudflare Manager</h2>
      <p>Manage your Cloudflare account (view zones, manage DNS, purge cache).</p>
      <button onClick={handlePurgeCache}>Purge All Cache</button>
      <p>Status: {status}</p>
      <p>Window ID: {windowId}</p>
      <button onClick={onClose}>Close App</button>
    </div>
  );
};
