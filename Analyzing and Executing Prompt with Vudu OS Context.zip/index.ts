//
// /backend/src/index.ts
// Main entry point for Cloudflare Pages Functions (Serverless API)
//

import { Hono } from 'hono';
import { Env } from '@shared/types';
import { getSupabaseServiceRoleClient } from '@mcp/supabase';
import { triggerN8nWorkflow } from '@mcp/n8n';

// Initialize Hono app
const app = new Hono<{ Bindings: Env }>();

// Middleware to check for authentication (basic example)
app.use('*', async (c, next) => {
  // In a real application, we would validate the Supabase JWT here.
  // For simplicity, we'll assume the frontend handles the user session
  // and passes a valid Authorization header for protected routes.
  // For now, we just ensure the environment is set up.
  try {
    c.get('Bindings').SUPABASE_SERVICE_ROLE_KEY; // Just a check
  } catch (e) {
    return c.json({ error: 'Server configuration error' }, 500);
  }
  await next();
});

// --- API Routes ---

// Example: Get a list of VFS nodes for a user (simplified)
app.get('/vfs/list/:parentId', async (c) => {
  const parentId = c.req.param('parentId');
  const supabase = getSupabaseServiceRoleClient(c.env);

  // NOTE: This route uses the Service Role Key, which bypasses RLS.
  // In a production app, you would use the user's JWT to authenticate
  // and rely on RLS for security. This is for demonstration of server-side logic.
  const { data, error } = await supabase
    .from('vfs_metadata')
    .select('*')
    .eq('parent_id', parentId === 'root' ? null : parentId)
    .order('type', { ascending: false }) // Folders first
    .order('name', { ascending: true });

  if (error) {
    console.error(error);
    return c.json({ error: 'Failed to fetch VFS list' }, 500);
  }

  return c.json(data);
});

// Example: Trigger n8n workflow for file processing
app.post('/workflow/trigger', async (c) => {
  const { workflowPath, payload } = await c.req.json();

  if (!workflowPath || !payload) {
    return c.json({ error: 'Missing workflowPath or payload' }, 400);
  }

  try {
    const response = await triggerN8nWorkflow(c.env, workflowPath, payload);
    const responseBody = await response.json();
    return c.json({ success: true, n8nResponse: responseBody }, response.status);
  } catch (error) {
    return c.json({ error: 'Failed to trigger workflow' }, 500);
  }
});

// Cloudflare Manager API: Purge Cache
app.post('/cloudflare/purge-cache', async (c) => {
  const { zoneId, files } = await c.req.json();
  const token = c.env.CLOUDFLARE_API_TOKEN;
  const accountId = c.env.CLOUDFLARE_ACCOUNT_ID;

  if (!zoneId || !token || !accountId) {
    return c.json({ error: 'Missing zoneId or Cloudflare credentials' }, 400);
  }

  const purgeUrl = `https://api.cloudflare.com/client/v4/zones/${zoneId}/purge_cache`;

  const response = await fetch(purgeUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({
      // Purge everything if no specific files are provided
      ...(files ? { files } : { purge_everything: true }),
    }),
  });

  const result = await response.json();

  if (!response.ok || !result.success) {
    console.error('Cloudflare API Error:', result);
    return c.json({ error: 'Cloudflare API failed', details: result }, response.status);
  }

  return c.json({ success: true, result });
});

// Fallback route for all other requests
app.all('*', (c) => c.json({ message: 'API Route Not Found' }, 404));

// Export the Hono app as the default handler for Cloudflare Pages Functions
export const onRequest = app.fetch;
