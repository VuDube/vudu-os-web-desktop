//
// /frontend/src/components/Taskbar/Taskbar.tsx
// The taskbar/dock component
//

import React from 'react';
import { useOSStore } from '../../store/useOSStore';

export const Taskbar: React.FC = () => {
  const { windows, focusWindow, apps } = useOSStore();

  const handleAppLaunch = (appId: string) => {
    // Logic to open a new instance of the app
    const app = apps.find(a => a.id === appId);
    if (app) {
      useOSStore.getState().openApp(appId);
    }
  };

  return (
    <div className="taskbar">
      {/* Start Menu Button (Simplified) */}
      <button
        className="start-button"
        onClick={() => console.log('Open Start Menu')}
        style={{ padding: '5px 10px', marginRight: '10px', fontWeight: 'bold' }}
      >
        vudu
      </button>

      {/* Quick Launch Icons (Example: File Explorer) */}
      <button
        title="File Explorer"
        onClick={() => handleAppLaunch('file-explorer')}
        style={{ padding: '5px', marginRight: '5px' }}
      >
        📁
      </button>

      {/* Running Windows */}
      <div style={{ display: 'flex', flexGrow: 1 }}>
        {windows.map((window) => (
          <button
            key={window.id}
            onClick={() => focusWindow(window.id)}
            style={{
              padding: '5px 10px',
              marginRight: '5px',
              backgroundColor: window.isMinimized ? '#444' : '#555',
              border: 'none',
              color: 'white',
              cursor: 'pointer',
            }}
          >
            {window.icon} {window.title}
          </button>
        ))}
      </div>

      {/* System Tray (Clock, Settings, etc.) */}
      <div style={{ marginLeft: 'auto' }}>
        {new Date().toLocaleTimeString()}
      </div>
    </div>
  );
};
