//
// /frontend/src/apps/MediaViewer/MediaViewerApp.tsx
// Media Viewer Application (Placeholder)
//

import React from 'react';
import { AppProps } from '@shared/types';

export const MediaViewerApp: React.FC<AppProps> = ({ windowId, onClose }) => {
  return (
    <div>
      <h2>🖼️ Media Viewer</h2>
      <p>View images and videos, leveraging Cloudinary's API for optimizations.</p>
      <p>Window ID: {windowId}</p>
      <button onClick={onClose}>Close App</button>
    </div>
  );
};
