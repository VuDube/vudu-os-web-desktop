//
// /frontend/src/App.tsx
// Main application component for vudu OS
//

import React, { useEffect } from 'react';
import { supabase } from './mcp/supabaseClient';
import { useOSStore } from './store/useOSStore';
import { Desktop } from './components/Desktop/Desktop';
import { Taskbar } from './components/Taskbar/Taskbar';
import { WindowManager } from './components/WindowManager/WindowManager';
import { LoginScreen } from './components/Auth/LoginScreen';
import { registerBuiltInApps } from './apps/apps';
import { getProfile } from './mcp/supabaseClient';

// Global styles (using styled-components or a CSS file)
import './App.css';

const App: React.FC = () => {
  const { isLoggedIn, setLoggedIn } = useOSStore();

  // Register all built-in applications on startup
  useEffect(() => {
    registerBuiltInApps();
  }, []);

  // Handle Supabase Auth state changes
  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session) {
        const profile = await getProfile();
        setLoggedIn(true, profile);
      } else {
        setLoggedIn(false, null);
      }
    });

    // Check initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session) {
        const profile = await getProfile();
        setLoggedIn(true, profile);
      } else {
        setLoggedIn(false, null);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [setLoggedIn]);

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  return (
    <div className="vudu-os-container">
      <Desktop />
      <WindowManager />
      <Taskbar />
    </div>
  );
};

export default App;
