import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'maskable_icon.png'],
      manifest: {
        name: 'vudu OS',
        short_name: 'vuduOS',
        description: 'A sophisticated, self-hostable Progressive Web App (PWA) Web Desktop Environment.',
        theme_color: '#000000',
        background_color: '#000000',
        display: 'standalone',
        icons: [
          {
            src: 'pwa-192x192.png',
            sizes: '192x192',
            type: 'image/png',
          },
          {
            src: 'pwa-512x512.png',
            sizes: '512x512',
            type: 'image/png',
          },
          {
            src: 'pwa-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
      workbox: {
        // Cache all core OS files and assets for offline use
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2,json}'],
        // Exclude the backend API calls from the service worker cache
        runtimeCaching: [
          {
            urlPattern: ({ url }) => url.pathname.startsWith('/api/'),
            handler: 'NetworkOnly',
          },
        ],
      },
    }),
  ],
  // Define the base directory for the frontend build
  root: './frontend',
  build: {
    outDir: '../dist', // Output to the root 'dist' folder for Cloudflare Pages
    emptyOutDir: true,
  },
  server: {
    // Proxy API requests to the backend functions during local development
    proxy: {
      '/api': {
        target: 'http://localhost:8788', // Default port for local Cloudflare Workers/Functions
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
});
