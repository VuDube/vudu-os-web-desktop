//
// /frontend/src/components/WindowManager/WindowManager.tsx
// Manages all open application windows
//

import React from 'react';
import { useOSStore } from '../../store/useOSStore';
import { Window } from './Window';

export const WindowManager: React.FC = () => {
  const { windows } = useOSStore();

  return (
    <div className="window-manager">
      {windows.map((windowState) => (
        <Window key={windowState.id} windowState={windowState} />
      ))}
    </div>
  );
};
