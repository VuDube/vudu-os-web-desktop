# vudu OS: Web Desktop Environment

**vudu OS** is a sophisticated, self-hostable Progressive Web App (PWA) Web Desktop Environment built with **React 18+**, **TypeScript**, and **Vite**. It leverages **Cloudflare Pages Functions** for a serverless backend and **Supabase** for a powerful, real-time backend-as-a-service.

The design philosophy is **"simplicity is sophistication"**, providing a clean, intuitive UI that is highly competitive and reveals powerful features upon use.

## 🚀 Core Technical Stack

| Component | Technology | Purpose | Free Tier Adherence |
| :--- | :--- | :--- | :--- |
| **Frontend** | React 18 + TypeScript + Vite | PWA Web Desktop UI | N/A |
| **Backend** | Cloudflare Pages Functions | Serverless API routes (Cloudflare Workers runtime) | Cloudflare Pages Free Tier |
| **Database/Auth** | Supabase (PostgreSQL) | Data storage, Real-time updates, User Authentication | Supabase Free Tier |
| **Storage** | Supabase Storage & Cloudinary | File storage and Media optimization/management | Supabase & Cloudinary Free Tiers |
| **Automation** | n8n (Self-hosted) | AI-powered and event-driven workflows | N/A (Requires self-hosted n8n) |

## 📦 Project Structure

This project uses a monorepo-like structure for organization:

```
.
├── backend/                  # Cloudflare Pages Functions (Serverless API)
│   └── src/
│       └── index.ts          # Main Hono app and API routes
├── frontend/                 # Vite/React PWA (The Web Desktop UI)
│   ├── src/
│   │   ├── apps/             # Built-in applications (File Explorer, etc.)
│   │   ├── components/       # Reusable UI components (Window, Taskbar, Auth)
│   │   ├── mcp/              # Frontend Supabase client and utility functions
│   │   ├── store/            # Zustand global state management
│   │   └── App.tsx           # Main application component
├── mcp/                      # Middleware, Communication, Persistence layer (Shared backend utilities)
│   └── src/
│       ├── supabase.ts       # Supabase Service Role client
│       ├── cloudinary.ts     # Cloudinary client and utilities
│       └── n8n.ts            # n8n webhook trigger utilities
├── shared/                   # Shared TypeScript types and constants
│   └── src/
│       └── types.ts          # Core data types (VFSNode, WindowState, etc.)
├── docs/                     # Documentation and configuration files
│   └── n8n_workflows.json    # Example n8n workflow schemas
├── .env.example              # Required environment variables
├── package.json              # Root scripts and dependencies
├── wrangler.toml             # Cloudflare Pages configuration
└── supabase_schema.sql       # SQL schema for Supabase
```

## 🛠️ Development Setup

### Prerequisites

1.  Node.js (v18+)
2.  npm
3.  Git
4.  A Cloudflare account
5.  A Supabase account
6.  A Cloudinary account

### Steps

1.  **Clone the repository:**
    ```bash
    git clone [YOUR_REPO_URL] vudu-os
    cd vudu-os
    ```

2.  **Install Dependencies:**
    ```bash
    npm run install:all
    ```

3.  **Configure Environment Variables:**
    *   Copy the example file: `cp .env.example .env`
    *   Fill in the required values in the newly created `.env` file. Note that for local development, you will need to set the `VITE_` variables in `.env`. The backend variables will be set in the Cloudflare Pages dashboard for production.

4.  **Set up Supabase:**
    *   Create a new Supabase project.
    *   Run the commands in `supabase_schema.sql` in the SQL Editor to set up the `profiles` and `vfs_metadata` tables, and the RLS policies.
    *   Go to **Storage** and create a new bucket named `vudu-files`. Set up RLS policies for this bucket to allow authenticated users to upload/download.

5.  **Run Locally (Frontend Only):**
    ```bash
    npm run dev
    ```
    This will start the Vite development server. The frontend will attempt to proxy API calls to the backend, which is not running yet.

6.  **Run Locally (Full Stack with Cloudflare Worker Simulation):**
    ```bash
    # In one terminal:
    npm run build
    # In a second terminal:
    npm run start:full
    ```
    This uses `wrangler pages dev` to simulate the Cloudflare Pages environment, including the Functions API, and serves the built frontend.

## ☁️ Deployment Guide

Please refer to the detailed `DEPLOYMENT.md` for step-by-step instructions on deploying vudu OS to Cloudflare Pages.
