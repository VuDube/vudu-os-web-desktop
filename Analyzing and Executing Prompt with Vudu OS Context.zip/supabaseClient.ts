//
// /frontend/src/mcp/supabaseClient.ts
// Supabase client and authentication utilities for the frontend
//

import { createClient } from '@supabase/supabase-js';
import { VFSNode, UserProfile } from '@shared/types';

// Supabase client for the frontend (uses the public anon key)
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL or Anon Key is missing in environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Fetches the current user's profile from the 'profiles' table.
 * @returns The user profile or null if not logged in or profile not found.
 */
export async function getProfile(): Promise<UserProfile | null> {
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return null;
  }

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  if (error) {
    console.error('Error fetching profile:', error);
    return null;
  }

  return data as UserProfile;
}

/**
 * List VFS nodes for a given parent ID.
 * @param parentId The ID of the parent folder, or 'root' for the user's root.
 * @returns A list of VFSNode objects.
 */
export async function listVFSNodes(parentId: string | 'root'): Promise<VFSNode[]> {
  // Use the backend API for listing to leverage server-side logic and security checks
  const response = await fetch(`/api/vfs/list/${parentId}`);
  if (!response.ok) {
    throw new Error('Failed to list VFS nodes');
  }
  return response.json();
}

/**
 * Uploads a file to Supabase Storage and creates a VFS metadata entry.
 * @param file The file to upload.
 * @param parentId The ID of the parent folder.
 * @returns The created VFSNode.
 */
export async function uploadFile(file: File, parentId: string): Promise<VFSNode> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) {
    throw new Error('User not authenticated');
  }

  const filePath = `${user.id}/${parentId}/${file.name}`;
  const { data: storageData, error: storageError } = await supabase.storage
    .from('vudu-files') // Assuming the bucket name is 'vudu-files'
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (storageError) {
    throw new Error(`Storage upload failed: ${storageError.message}`);
  }

  // Create VFS metadata entry
  const newNode: Partial<VFSNode> = {
    owner_id: user.id,
    parent_id: parentId,
    name: file.name,
    type: 'file',
    storage_type: 'supabase',
    storage_path: storageData.path,
    mime_type: file.type,
    size_bytes: file.size,
    metadata: {},
  };

  const { data: vfsData, error: vfsError } = await supabase
    .from('vfs_metadata')
    .insert([newNode])
    .select()
    .single();

  if (vfsError) {
    // Attempt to clean up the storage file if metadata creation fails
    await supabase.storage.from('vudu-files').remove([storageData.path]);
    throw new Error(`VFS metadata creation failed: ${vfsError.message}`);
  }

  return vfsData as VFSNode;
}
