//
// /shared/src/types.ts
// Core TypeScript types for vudu OS
//

/**
 * Represents a node in the Universal File System (UFS).
 */
export type VFSNode = {
  id: string;
  owner_id: string;
  parent_id: string | null;
  name: string;
  type: 'folder' | 'file' | 'link';
  storage_type: 'supabase' | 'cloudinary' | 'local';
  storage_path: string | null; // Supabase Storage path or Cloudinary public_id
  mime_type: string | null;
  size_bytes: number | null;
  created_at: string;
  updated_at: string;
  is_public: boolean;
  metadata: Record<string, any>; // For Cloudinary tags, local path, etc.
};

/**
 * Represents the manifest for a vudu OS application.
 */
export type AppManifest = {
  id: string;
  name: string;
  icon: string; // Path to icon image or a simple emoji
  component: React.FC<AppProps>; // The React component for the app
  isExternal: boolean; // If true, the app is launched in an iframe
  url?: string; // URL for external apps
};

/**
 * Props passed to every vudu OS application component.
 */
export type AppProps = {
  windowId: string;
  onClose: () => void;
  // Additional props for specific app functionality can be added here
};

/**
 * Represents a single window state in the OS.
 */
export type WindowState = {
  id: string;
  appId: string;
  title: string;
  icon: string;
  x: number;
  y: number;
  width: number;
  height: number;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
};

/**
 * Represents a user profile, extending the Supabase user data.
 */
export type UserProfile = {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  os_settings: Record<string, any>;
  updated_at: string | null;
};

/**
 * Environment variables available in the backend (Cloudflare Pages Functions).
 */
export type Env = {
  SUPABASE_SERVICE_ROLE_KEY: string;
  CLOUDFLARE_API_TOKEN: string;
  CLOUDFLARE_ACCOUNT_ID: string;
  CLOUDINARY_API_KEY: string;
  CLOUDINARY_API_SECRET: string;
  N8N_WEBHOOK_BASE_URL: string;
  N8N_WEBHOOK_SECRET: string;
};
