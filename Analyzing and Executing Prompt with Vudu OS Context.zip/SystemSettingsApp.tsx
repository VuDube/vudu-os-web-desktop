//
// /frontend/src/apps/SystemSettings/SystemSettingsApp.tsx
// System Settings Application (Placeholder)
//

import React from 'react';
import { AppProps } from '@shared/types';

export const SystemSettingsApp: React.FC<AppProps> = ({ windowId, onClose }) => {
  return (
    <div>
      <h2>⚙️ System Settings</h2>
      <p>Configure the OS, connect new services, and set environment variables.</p>
      <p>Window ID: {windowId}</p>
      <button onClick={onClose}>Close App</button>
    </div>
  );
};
