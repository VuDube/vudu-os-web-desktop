//
// /mcp/src/n8n.ts
// n8n webhook utility functions for the backend (Cloudflare Pages Functions)
//

import { Env } from '@shared/types';

/**
 * Triggers a specific n8n workflow via a webhook.
 * @param env The environment variables.
 * @param workflowPath The path of the n8n webhook (e.g., 'webhook/cloudinary-tagger').
 * @param data The payload to send to the workflow.
 * @returns The response from the n8n webhook.
 */
export async function triggerN8nWorkflow(env: Env, workflowPath: string, data: any): Promise<Response> {
  const baseUrl = env.N8N_WEBHOOK_BASE_URL;
  const secret = env.N8N_WEBHOOK_SECRET;

  if (!baseUrl || !secret) {
    console.warn('n8n base URL or secret is not configured. Skipping workflow trigger.');
    return new Response(JSON.stringify({ message: 'n8n not configured' }), { status: 200 });
  }

  const url = `${baseUrl}/${workflowPath}?secret=${secret}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      console.error(`n8n webhook failed with status: ${response.status}`);
    }

    return response;
  } catch (error) {
    console.error('Error triggering n8n workflow:', error);
    return new Response(JSON.stringify({ error: 'Failed to connect to n8n' }), { status: 500 });
  }
}
